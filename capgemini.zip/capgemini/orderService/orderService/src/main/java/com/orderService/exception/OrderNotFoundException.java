package com.orderService.exception;

public class OrderNotFoundException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OrderNotFoundException(String orderId){
		super(String.format("ORDER NOT FOUND IN DB"+ orderId));
	}}
